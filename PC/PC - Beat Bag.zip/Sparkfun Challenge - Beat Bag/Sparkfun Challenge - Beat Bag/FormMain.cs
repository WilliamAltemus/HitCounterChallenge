﻿//////////////////////////
//                      //
//  SparkFun Challenge  //
//       Beat Bag       //
//                      //
//    William Altemus   //
//        6-20-16       //
//                      //
//////////////////////////

/*
 License: This code is public domain but you buy me a beer if you use this and we meet someday (Beerware license).

 This was produced as part of participation in the SparkFun contest to create an algorithm that can accurately count speed bag hits
 * based on raw data from a 3-axis accelerometer

 My initial understanding of the challenge was that the counter was mounted on the bag itself. Based on that I treated the bag as an
 * ideal pendulum where the Z axis was just extraneous information and a source of extra noise in the system. I focused instead on
 * only the X and Y axes. Even though the sensor is actually mounted to the platform, using only X and Y still yields better results.
 * I believe this is due to the angle at which the boxer strikes the bag: a primarily lateral direction. Using only X and Y further
 * reduces the impact of signal noise as the bag hits the platform. By not considering the Z axis, we don't read the upward impact
 * of the bag into the platform.
 
 My first step was to take 75 data points for both X and Y while the bag was stationary. I used the average of these points as the
 * offset to account for initial tilt of the sensor. In order to more easily and accurately find local maxima in the data, I wanted
 * to keep the vector magnitude while at rest as close as possible to zero.
 
 Second, I found that I needed a way to filter low amplitude, long duration impacts so that I could detect them more easily.
 * By looking at each data point summed with the previous 75, The low amplitude, long duration impacts start to look more like the
 * high amplitude, short duration impacts. When I graphed the new data, I could see consistently taller peaks with less noise.
  
 Once I had the data filtered in such a way that I could visually see and count where the hits were occuring on a graph, I had to
 * come up with a way to interpret them within my algorithm. I decided to use a sliding window approach to find the local maxima.
 * I used a collection of the newest 151 sums (these are the sums of 75 individual values), using the median sum as the data 
 * point I was examining. I checked the 75 values prior to the data point in question and the 75 values after the data point in
 * question to see if the data point in question was "significantly" greater than the surrounding data points. Using a variance
 * minimum of 25% seemed to yield the most accurate and consistent results. I used 151 sums in my analysis, because hits on the bag
 * had an average period of 300ms. Capturing data at 500Hz means 150 data points between peaks on the graph (hits), but it also means 
 * 150 data points between troughs. This gives me a good probability of finding the low point in a shallow trough and not getting a 
 * false negative result from the test. Another filter I needed to implement before accepting the data point as a local maxima or
 * hit on the speed bag was a high pass filter. Based on visual inspection of the graphed data, I determined that any actual hit on
 * the speed bag would have an amplitude greater than 4.5. If the data point being inspected had a value less than the threshold, it
 * failed the test. The final filter the data point had to pass through was a question of, "Just how quickly can someone land repeated
 * strikes on a speed bag?" I stored the time of the previous accepted hit in a variable. If the current data point in question had a 
 * time stamp that was sufficiently chronologically spaced from the previous hit, then we could confirm a new hit.
  
 I learned a lot of new tricks to add to my ever-growing bag while working on this project. I hope this helps you all in some way!
  
 William
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Sparkfun_Challenge___Beat_Bag
{
    public partial class FormMain : Form
    {
        #region Globals

        string _fileName = string.Empty;
        int _numHits = 0;
        int _minVariance = 25; //(10-90) the minimum variance percentage a point must have over surrounding points to be a local maxima

        #endregion

        public FormMain()
        {
            InitializeComponent();
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            //set up a dialog to get file name from user
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            //get file name from user
            DialogResult result = openFileDialog.ShowDialog();

            //if the user selected a file name, display it in the text box and set it as our global variable _fileName
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                textBoxFileName.Text = openFileDialog.FileName;
                _fileName = openFileDialog.FileName;
            }
        }

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            //reset chart
            ChartReset();

            //reset global variable _numHits
            _numHits = 0;

            //variable to hold the time of our last hit
            int timeLastHit = 0;

            //int to keep track of which line we are currently reading
            int lineCounter = 0;

            //floating point numbers to hold offsets for initial tilt in X and Y axes
            double offsetX = 0;
            double offsetY = 0;

            //floating point number to hold our current XY vector amplitude
            double currVector;

            //floating point number to hold our current data sum
            double currSum = 0;

            //int to hold the number of vector amplitudes we have added to our data sum
            int sumCount = 0;

            //a FIFO queue to hold our last 151 calculated vectors
            //the period between punches is about 300ms 
            //recording data at 500Hz means we have about 150 data points between punches
            //we will use the Queue to implement a sliding window filter with a width of +/- 75 data points
            //as we get new data points, the newest will be added to our sum and the oldest will be dropped
            Queue<double> data = new Queue<double>();

            //another FIFO queue will be used to hold our sums
            //this queue will be passed to CheckLocalMaxima to see if the median data point is in fact a local maxima
            Queue<double> sumData = new Queue<double>();

            //string to hold each line of our file as we read it
            string line;

            try //if something goes horribly wrong the try/catch structure will keep our program from crashing
            {
                //open text file for reading
                //we will read one line at a time as we process it
                //as if we were aquiring the data in real time
                StreamReader streamReader = new StreamReader(_fileName);

                //read file line by line until the end is reached
                //we are going to use the first 75 values to calculate an average offset
                //that we will apply to the XY values to compensate for initial tilt
                //we want to keep our resting normalized value as close to zero as we can to 
                //make it easier to find localized maxima
                while ((line = streamReader.ReadLine()) != null)
                {
                    //first we will break the line into it's 4 component parts: timestamp/x/y/z
                    //the parts are separated by a comma
                    string[] parts = line.Split(',');

                    //make sure we have 4 parts
                    //otherwise we are looking at some intro characters or an error
                    //and need to skip to the next line of the file
                    if (parts.Length != 4)
                        continue;

                    //parse the values we are reading from string to double
                    //convert from a 4g range of -2047 to 2047 into a 1g range of -1 to 1
                    //add them into the cumulative values we are building
                    offsetX += double.Parse(parts[1]) / 2047 * 4;
                    offsetY += double.Parse(parts[2]) / 2047 * 4;

                    //on the 75th line (counter starts at 0) we will take our cumulative value and divide it by 75 to get our averages
                    //next we will start to calculate XY vector amplitude from the X and Y data
                    //we will use the current calculated vector amplitude plus the previous 74 to find our localized maxima
                    if (lineCounter == 74)
                    {
                        offsetX = offsetX / 75;
                        offsetY = offsetY / 75;

                        //break out of the loop and continue to the magic
                        break;
                    }

                    //increment counter
                    lineCounter++;
                }

                //this is where the magic happens
                //continue reading file line by line until the end is reached
                while ((line = streamReader.ReadLine()) != null)
                {
                    //first we will break the line into it's 4 component parts: timestamp/x/y/z
                    //the parts are separated by a comma
                    string[] parts = line.Split(',');

                    //make sure we have 4 parts
                    //otherwise we are looking at some intro characters or an error
                    //and need to skip to the next line of the file
                    if (parts.Length != 4)
                        continue;

                    //calculate X and Y
                    //convert from a 4g range of -2047 to 2047 into a 1g range of -1 to 1
                    //then apply offset
                    double currX = double.Parse(parts[1]) / 2047 * 4 - offsetX;
                    double currY = double.Parse(parts[2]) / 2047 * 4 - offsetY;

                    //calculate current XY vector amplitude
                    currVector = Math.Sqrt((currX * currX)+(currY * currY));

                    //enqueue our newest calculated vector amplitude to our data queue
                    //we need to track exactly 75 values
                    //once we have 75 we need to start subtracting them from our 
                    //curr sum as we add new ones
                    data.Enqueue(currVector);

                    //add our newest calculated vector amplitude to our curr sum
                    //we want to have the 75 latest values in this sum before we
                    //add it to the sumData queue and start looking for local maxima
                    currSum += currVector;

                    //increment our counter that tracks how many values we have added to our sum
                    sumCount++;

                    //if we have added enough values to our sum
                    if (sumCount >= 75)
                    {
                        //start adding sums to our sumData queue
                        //this tracks the latest 151 instances of what our currSum value held
                        //and will be used to check for local maxima
                        sumData.Enqueue(currSum);

                        //add sum to chart
                        Series series = this.chartDataPoints.Series[0];
                        series.Points.Add(currSum);
                    }

                    //we need to have 151 values loaded into our sumData queue before we start
                    //looking for local maxima
                    //if we have exceeded our target sumData queue size of 151
                    if (sumData.Count > 151)
                    {
                        //take the oldest value out from the front of the queue
                        sumData.Dequeue();

                        //check if our median sumData queue value is a local maxima
                        if (CheckLocalMaxima(sumData))
                        {
                            //parse the value of the current timestamp
                            int currTime = Int32.Parse(parts[0]);

                            //if it has been at least 200ms since our last hit
                            if (currTime - timeLastHit > 200)
                            {
                                //save the currTime into timeLastHit
                                timeLastHit = currTime;

                                //increment hit counter
                                _numHits++;

                                //add annotation to chart to show hit detected
                                //we pass our current sumData Queue so that the method
                                //can pull from it the value that was determined to be
                                //a hit on the speed bag
                                ChartAddAnnotation(sumData);
                            }
                        }
                    }

                    //if we have reached 75 data points in our sum
                    //subtract the oldest data from our currSum to get ready for the next to be added
                    //this will also remove the oldest data point from our data queue
                    if (sumCount >= 75)
                    {
                        currSum -= data.Dequeue();
                    }
                }

                //close the file
                streamReader.Close();

                //post hit count to textBoxHitCount
                textBoxHitCount.Text = _numHits.ToString();
            }
            catch
            {
                MessageBox.Show("Uh-oh.. Something went wrong here");
                return;
            }
        }

        private bool CheckLocalMaxima(Queue<double> sumData)
        {
            //store our current value we are checking against
            //this is the median value
            double currVal = sumData.ElementAt(75);

            //check against minimum vector amplitude for an actual hit
            if (currVal < 4.5)
                return false;

            //calculate what our minimum variance must be to have a local maxima based on the global value _minVariance
            double minVariance = currVal * (((double)100 - _minVariance) / (double)100);

            //check left side of median point
            for (int i = 70; i >= 0; i -= 1)
            {
                //if current point we are checking has minimum variance on the left side to be a local maxima
                if (minVariance > sumData.ElementAt(i))
                {
                    //check right side of median point
                    for (int j = 80; j < 151; j += 1)
                    {
                        //if current point we are checking has minimum variance on the right side to be a local maxima
                        if (minVariance > sumData.ElementAt(j))
                        {
                            return true;
                        }
                    }

                    //if we reach this point we did not have enough variance on the right side to be a local maxima
                    //we can speed up the process by returning false now
                    //otherwise we would check the entire right side for every left hand point
                    //that matches our criteria
                    return false;
                }
            }

            //the point we were checking failed the test
            return false;
        }

        private void ChartAddAnnotation(Queue<double> sumData)
        {
            //an ellipse annotation object
            //we will define the properties of the object then add it to our chart
            EllipseAnnotation ellipse = new EllipseAnnotation();
            ellipse.Height = 1;
            ellipse.Width = .5;

            //find the data point that was determined to be a hit on the speed bag
            DataPoint point = chartDataPoints.Series[0].Points.FindByValue(sumData.ElementAt(75));

            //find the index of the data point
            int pointIndex = chartDataPoints.Series[0].Points.IndexOf(point);

            //add the ellipse to the collection of annotations on the chart
            chartDataPoints.Annotations.Add(ellipse);

            //anchor the ellipse to the proper data point
            chartDataPoints.Annotations[_numHits - 1].AnchorDataPoint = chartDataPoints.Series[0].Points[pointIndex];
        }

        private void ChartReset()
        {
            //clear the current series of data points from the chart
            chartDataPoints.Series.Clear();

            //clear the collection of annotations from the chart
            chartDataPoints.Annotations.Clear();

            //add a new series to hold our new data
            chartDataPoints.Series.Add("Data");

            //set chart type
            chartDataPoints.Series[0].ChartType = SeriesChartType.Line;

            //set the chart to not show grid lines
            chartDataPoints.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartDataPoints.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
        }
    }
}
