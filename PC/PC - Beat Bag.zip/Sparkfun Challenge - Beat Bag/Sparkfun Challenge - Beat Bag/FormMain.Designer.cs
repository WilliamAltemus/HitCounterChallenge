﻿namespace Sparkfun_Challenge___Beat_Bag
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.textBoxFileName = new System.Windows.Forms.TextBox();
            this.labelFile = new System.Windows.Forms.Label();
            this.buttonBrowse = new System.Windows.Forms.Button();
            this.chartDataPoints = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.labelHitCount = new System.Windows.Forms.Label();
            this.textBoxHitCount = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.chartDataPoints)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxFileName
            // 
            this.textBoxFileName.Location = new System.Drawing.Point(44, 12);
            this.textBoxFileName.Name = "textBoxFileName";
            this.textBoxFileName.Size = new System.Drawing.Size(229, 20);
            this.textBoxFileName.TabIndex = 0;
            // 
            // labelFile
            // 
            this.labelFile.AutoSize = true;
            this.labelFile.Location = new System.Drawing.Point(12, 15);
            this.labelFile.Name = "labelFile";
            this.labelFile.Size = new System.Drawing.Size(26, 13);
            this.labelFile.TabIndex = 1;
            this.labelFile.Text = "File:";
            // 
            // buttonBrowse
            // 
            this.buttonBrowse.Location = new System.Drawing.Point(279, 10);
            this.buttonBrowse.Name = "buttonBrowse";
            this.buttonBrowse.Size = new System.Drawing.Size(75, 23);
            this.buttonBrowse.TabIndex = 2;
            this.buttonBrowse.Text = "Browse";
            this.buttonBrowse.UseVisualStyleBackColor = true;
            this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
            // 
            // chartDataPoints
            // 
            this.chartDataPoints.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.Name = "ChartArea1";
            this.chartDataPoints.ChartAreas.Add(chartArea1);
            this.chartDataPoints.Location = new System.Drawing.Point(12, 39);
            this.chartDataPoints.Name = "chartDataPoints";
            this.chartDataPoints.Size = new System.Drawing.Size(988, 523);
            this.chartDataPoints.TabIndex = 3;
            this.chartDataPoints.Text = "chart1";
            // 
            // buttonCalc
            // 
            this.buttonCalc.Location = new System.Drawing.Point(360, 10);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(175, 23);
            this.buttonCalc.TabIndex = 4;
            this.buttonCalc.Text = "Calculate Hit Count";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // labelHitCount
            // 
            this.labelHitCount.AutoSize = true;
            this.labelHitCount.Location = new System.Drawing.Point(608, 15);
            this.labelHitCount.Name = "labelHitCount";
            this.labelHitCount.Size = new System.Drawing.Size(57, 13);
            this.labelHitCount.TabIndex = 5;
            this.labelHitCount.Text = "Hit Count: ";
            // 
            // textBoxHitCount
            // 
            this.textBoxHitCount.Location = new System.Drawing.Point(661, 12);
            this.textBoxHitCount.Name = "textBoxHitCount";
            this.textBoxHitCount.Size = new System.Drawing.Size(50, 20);
            this.textBoxHitCount.TabIndex = 6;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1012, 574);
            this.Controls.Add(this.textBoxHitCount);
            this.Controls.Add(this.labelHitCount);
            this.Controls.Add(this.buttonCalc);
            this.Controls.Add(this.chartDataPoints);
            this.Controls.Add(this.buttonBrowse);
            this.Controls.Add(this.labelFile);
            this.Controls.Add(this.textBoxFileName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "Sparkfun Challenge - Beat Bag";
            ((System.ComponentModel.ISupportInitialize)(this.chartDataPoints)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxFileName;
        private System.Windows.Forms.Label labelFile;
        private System.Windows.Forms.Button buttonBrowse;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDataPoints;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.Label labelHitCount;
        private System.Windows.Forms.TextBox textBoxHitCount;
    }
}

