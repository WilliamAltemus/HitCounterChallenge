﻿//////////////////////////
//                      //
//  SparkFun Challenge  //
//       Beat Bag       //
//                      //
//    William Altemus   //
//        6-20-16       //
//                      //
//////////////////////////

/*
 License: This code is public domain but you buy me a beer if you use this and we meet someday (Beerware license).

 This was produced as part of participation in the SparkFun contest to create an algorithm that can accurately count speed bag hits
 * based on raw data from a 3-axis accelerometer

 My initial understanding of the challenge was that the counter was mounted on the bag itself. Based on that I treated the bag as an
 * ideal pendulum where the Z axis was just extraneous information and a source of extra noise in the system. I focused instead on
 * only the X and Y axes. Even though the sensor is actually mounted to the platform, using only X and Y still yields better results.
 * I believe this is due to the angle at which the boxer strikes the bag: a primarily lateral direction. Using only X and Y further
 * reduces the impact of signal noise as the bag hits the platform. By not considering the Z axis, we don't read the upward impact
 * of the bag into the platform.
 
 My first step was to take 75 data points for both X and Y while the bag was stationary. I used the average of these points as the
 * offset to account for initial tilt of the sensor. In order to more easily and accurately find local maxima in the data, I wanted
 * to keep the vector magnitude while at rest as close as possible to zero.
 
 Second, I found that I needed a way to filter low amplitude, long duration impacts so that I could detect them more easily.
 * By looking at each data point summed with the previous 75, The low amplitude, long duration impacts start to look more like the
 * high amplitude, short duration impacts. When I graphed the new data, I could see consistently taller peaks with less noise.
  
 Once I had the data filtered in such a way that I could visually see and count where the hits were occuring on a graph, I had to
 * come up with a way to interpret them within my algorithm. I decided to use a sliding window approach to find the local maxima.
 * I used a collection of the newest 151 sums (these are the sums of 75 individual values), using the median sum as the data 
 * point I was examining. I checked the 75 values prior to the data point in question and the 75 values after the data point in
 * question to see if the data point in question was "significantly" greater than the surrounding data points. Using a variance
 * minimum of 25% seemed to yield the most accurate and consistent results. I used 151 sums in my analysis, because hits on the bag
 * had an average period of 300ms. Capturing data at 500Hz means 150 data points between peaks on the graph (hits), but it also means 
 * 150 data points between troughs. This gives me a good probability of finding the low point in a shallow trough and not getting a 
 * false negative result from the test. Another filter I needed to implement before accepting the data point as a local maxima or
 * hit on the speed bag was a high pass filter. Based on visual inspection of the graphed data, I determined that any actual hit on
 * the speed bag would have an amplitude greater than 4.5. If the data point being inspected had a value less than the threshold, it
 * failed the test. The final filter the data point had to pass through was a question of, "Just how quickly can someone land repeated
 * strikes on a speed bag?" I stored the time of the previous accepted hit in a variable. If the current data point in question had a 
 * time stamp that was sufficiently chronologically spaced from the previous hit, then we could confirm a new hit.
  
 I learned a lot of new tricks to add to my ever-growing bag while working on this project. I hope this helps you all in some way!
  
 William
*/

using System;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Microsoft.SPOT;
using Microsoft.SPOT.Hardware;
using SecretLabs.NETMF.Hardware;
using SecretLabs.NETMF.Hardware.NetduinoPlus;

namespace BeatBag
{
    public class Program
    {
        #region Globals

        string _fileName = string.Empty;
        public static int _numHits = 0;
        public static int _minVariance = 25; //(10-90) the minimum variance percentage a point must have over surrounding points to be a local maxima

        #endregion

        public static void Main()
        {
            // !!!!!!!not yet implemented!!!!!!!
            //setup pins
            //setup I2C
            //init display
            //test and init the accel - wait for it to be initialized

            //call CountHits to start collecting, parsing, and displaying data
            CountHits();
        }

        //this method is called once the accelerometer has initialized
        //it will continuously gather data and parse it to find and count hits
        public static void CountHits()
        {
            //variable to hold the time of our last hit
            long timeLastHit = 0;

            //int to keep track of which line we are currently reading
            int lineCounter = 0;

            //floating point numbers to hold offsets for initial tilt in X and Y axes
            double offsetX = 0;
            double offsetY = 0;

            //floating point number to hold our current XY vector amplitude
            double currVector;

            //floating point number to hold our current data sum
            double currSum = 0;

            //int to hold the number of vector amplitudes we have added to our data sum
            int sumCount = 0;

            //a FIFO queue to hold our last 151 calculated vectors
            //the period between punches is about 300ms 
            //recording data at 500Hz means we have about 150 data points between punches
            //we will use the Queue to implement a sliding window filter with a width of +/- 75 data points
            //as we get new data points, the newest will be added to our sum and the oldest will be dropped
            Queue data = new Queue();

            //another FIFO queue will be used to hold our sums
            //this queue will be passed to CheckLocalMaxima to see if the median data point is in fact a local maxima
            Queue sumData = new Queue();

            try //if something goes horribly wrong the try/catch structure will keep our program from crashing
            {
                //gather data from the accelerometer
                //we are going to use the first 75 values to calculate an average offset
                //that we will apply to the XY values to compensate for initial tilt
                //we want to keep our resting values as close to zero as we can to 
                //make it easier to find localized maxima
                while (true)
                {
                    //variables to hold our accel data
                    int dataX = 0;
                    int dataY = 0;

                    //get accel data and store in dataX and dataY
                    GetAccelData(ref dataX, ref dataY);

                    //parse the values we are reading from string to double
                    //convert from a 4g range of -2047 to 2047 into a 1g range of -1 to 1
                    //add them into the cumulative values we are building
                    offsetX += dataX / 2047 * 4;
                    offsetY += dataY / 2047 * 4;

                    //on the 75th line (counter starts at 0) we will take our cumulative value and divide it by 75 to get our averages
                    //next we will start to calculate XY vector amplitude from the X and Y data
                    //we will use the current calculated vector amplitude plus the previous 74 to find our localized maxima
                    if (lineCounter == 74)
                    {
                        offsetX = offsetX / 75;
                        offsetY = offsetY / 75;

                        //break out of the loop and continue to the magic
                        break;
                    }

                    //increment counter
                    lineCounter++;
                }

                //this is where the magic happens
                //continue gathering data from the accelerometer
                while (true)
                {
                    //variables to hold our accel data
                    int dataX = 0;
                    int dataY = 0;

                    //get accel data and store in dataX and dataY
                    GetAccelData(ref dataX, ref dataY);

                    //calculate X and Y
                    //convert from a 4g range of -2047 to 2047 into a 1g range of -1 to 1
                    //then apply offset
                    double currX = dataX / 2047 * 4 - offsetX;
                    double currY = dataY / 2047 * 4 - offsetY;

                    //calculate current XY vector amplitude
                    currVector = System.Math.Sqrt((currX * currX) + (currY * currY));

                    //enqueue our newest calculated vector amplitude to our data queue
                    //we need to track exactly 75 values
                    //once we have 75 we need to start subtracting them from our 
                    //curr sum as we add new ones
                    data.Enqueue(currVector);

                    //add our newest calculated vector amplitude to our curr sum
                    //we want to have the 75 latest values in this sum before we
                    //add it to the sumData queue and start looking for local maxima
                    currSum += currVector;

                    //increment our counter that tracks how many values we have added to our sum
                    sumCount++;

                    //if we have added enough values to our sum
                    if (sumCount >= 75)
                    {
                        //start adding sums to our sumData queue
                        //this tracks the latest 151 instances of what our currSum value held
                        //and will be used to check for local maxima
                        sumData.Enqueue(currSum);
                    }

                    //we need to have 151 values loaded into our sumData queue before we start
                    //looking for local maxima
                    //if we have exceeded our target sumData queue size of 151
                    if (sumData.Count > 151)
                    {
                        //take the oldest value out from the front of the queue
                        sumData.Dequeue();

                        //check if our median sumData queue value is a local maxima
                        if (CheckLocalMaxima(sumData))
                        {
                            //get the current time in milliseconds
                            //10000 Ticks ~ 1 ms
                            long currTime = DateTime.Now.Ticks / 10000;

                            //if it has been at least 200ms since our last hit
                            if (currTime - timeLastHit > 200)
                            {
                                //save the currTime into timeLastHit
                                timeLastHit = currTime;

                                //increment hit counter
                                _numHits++;

                                //update hit count display
                                UpdateDisplay(_numHits);
                            }
                        }
                    }

                    //if we have reached 75 data points in our sum
                    //subtract the oldest data from our currSum to get ready for the next to be added
                    //this will also remove the oldest data point from our data queue
                    if (sumCount >= 75)
                    {
                        currSum -= (double)data.Dequeue();
                    }
                }
            }
            catch
            {
                //do something to show we had an error
                BlinkError();
                return;
            }
        }

        // !!!!!!!not yet implemented!!!!!!!
        public static void GetAccelData(ref int dataX, ref int dataY)
        {
            //pull data from accel
            //save raw X axis data in dataX
            //save raw Y axis data in dataY
        }

        public static bool CheckLocalMaxima(Queue sumData)
        {
            //convert our queue to an object array so that we can look at values within it
            object[] sumDataArray = sumData.ToArray();

            //store our current value we are checking against
            //this is the median value
            double currVal = (double)sumDataArray[75];

            //check against minimum vector amplitude for an actual hit
            if (currVal < 4.5)
                return false;

            //calculate what our minimum variance must be to have a local maxima based on the global value _minVariance
            double minVariance = currVal * (((double)100 - _minVariance) / (double)100);

            //check left side of median point
            for (int i = 70; i >= 0; i -= 1)
            {
                //if current point we are checking has minimum variance on the left side to be a local maxima
                if (minVariance > (double)sumDataArray[i])
                {
                    //check right side of median point
                    for (int j = 80; j < 151; j += 1)
                    {
                        //if current point we are checking has minimum variance on the right side to be a local maxima
                        if (minVariance > (double)sumDataArray[j])
                        {
                            return true;
                        }
                    }

                    //if we reach this point we did not have enough variance on the right side to be a local maxima
                    //we can speed up the process by returning false now
                    //otherwise we would check the entire right side for every left hand point
                    //that matches our criteria
                    return false;
                }
            }

            //the point we were checking failed the test
            return false;
        }

        // !!!!!!!not yet implemented!!!!!!!
        public static void UpdateDisplay(int numHits)
        {
            //print numHits to the display
        }

        // !!!!!!!not yet implemented!!!!!!!
        public static void BlinkError()
        {
            //blink the on-board LED is some fashion to signal an error
        }
    }
}
